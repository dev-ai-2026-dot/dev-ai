export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Use POST for chat requests." }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "GEMINI_API_KEY is missing in Netlify environment variables." }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json();
    const message = typeof body.message === "string" ? body.message.trim() : "";
    if (!message) {
      return new Response(JSON.stringify({ error: "Message is empty." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: message }] }] }),
    });
    const data = await response.json();
    if (!response.ok) {
      const apiMessage = data?.error?.message || `Gemini request failed (${response.status}).`;
      return new Response(JSON.stringify({ error: apiMessage }), {
        status: response.status,
        headers: { "Content-Type": "application/json" },
      });
    }
    const reply = data?.candidates?.[0]?.content?.parts?.map(part => part.text || "").join("\n").trim();
    return new Response(JSON.stringify({ reply: reply || "Gemini se jawab nahi mila." }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch {
    return new Response(JSON.stringify({ error: "Request process nahi ho saki. Dobara try karo." }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};
